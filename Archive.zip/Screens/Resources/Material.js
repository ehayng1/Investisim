import {
  ScrollView,
  StyleSheet,
  Text,
  View,
  Image,
  Pressable,
} from "react-native";
import { Dimensions } from "react-native";
const screenWidth = Dimensions.get("window").width;
const screenHeigth = Dimensions.get("window").height;

export function Week1() {
  return (
    <ScrollView>
      <View style={{ marginHorizontal: 0 }}>
        <Text
          style={{
            fontSize: 22,
            textAlign: "center",
            fontWeight: "600",
            marginTop: 20,
            marginBottom: 40,
          }}
        >
          Day Trading
        </Text>
        {/* <Image
          style={{ marginLeft: 10, width: 350, height: 250, marginBottom: 30 }}
          source={require("../../data/week2.png")}
        ></Image> */}
        <View
          style={{
            // display: "flex",
            // flexDirection: "row",
            marginBottom: 10,
            justifyContent: "space-around",
          }}
        >
          <View style={{ marginRight: 25, marginLeft: 10 }}>
            <View
              style={{
                marginBottom: 15,
                display: "flex",
                flexDirection: "row",
              }}
            >
              <Text style={[styles.subtitle]}>Audience</Text>
              <Text
                style={{
                  color: "green",
                  fontSize: 15,
                  fontWeight: "500",
                  justifyContent: "flex-end",
                }}
              >
                Beginners
              </Text>
            </View>

            <View
              style={{
                marginBottom: 15,
                display: "flex",
                flexDirection: "row",
              }}
            >
              <Text style={[styles.subtitle, {}]}>Company Size</Text>
              <Text style={{ fontSize: 15, fontWeight: "500" }}>
                Mid & Small
              </Text>
            </View>
            <View
              style={{
                marginBottom: 15,
                display: "flex",
                flexDirection: "row",
              }}
            >
              <Text style={styles.subtitle}>Risk/Profit</Text>
              <Text
                style={{
                  fontSize: 17,
                  fontWeight: "500",
                }}
              >
                3.5 / 5
              </Text>
            </View>
          </View>
        </View>
        <View style={{ marginHorizontal: 10 }}>
          <Text
            style={{
              marginVertical: 5,
              marginBottom: 15,
              fontWeight: "600",
              fontSize: 18,
              // color: "#808080",
            }}
          >
            Summary
          </Text>
          <Text
            style={{
              fontFamily: "Arial",
              fontWeight: "400",
              fontSize: 15,
              marginBottom: 30,
              color: "#505050",
            }}
          >
            Day trading is a strategy where stocks and securities are traded on
            a daily basis, where investors exploit the daily volatility to earn
            money. Less risk present in the market as the trading term is pretty
            short. Has a relatively lower risk compared to other strategies.
          </Text>
        </View>
      </View>
    </ScrollView>
  );
}

export function Week2({ navigation }) {
  return (
    <ScrollView>
      <View style={{ marginHorizontal: 0 }}>
        <Text style={styles.title}>Position Trading</Text>

        <Text style={styles.summary}>
          Position trading is a strategy where traders analyze the market trend
          over several weeks to look for continuous volatility. After
          identifying the “waves”, traders seek to buy on low points and sell on
          high points. Time consuming for the expense of ensured profit. People
          who wish to earn money safely at the expense of time.
        </Text>

        <Image
          style={styles.image}
          source={require("../../data/Weeks/week2.png")}
        ></Image>

        <View
          style={{
            marginBottom: 10,
            justifyContent: "space-around",
          }}
        >
          <View style={{ marginRight: 25, marginLeft: 10 }}>
            <View
              style={{
                marginBottom: 15,
                display: "flex",
                flexDirection: "row",
              }}
            >
              <Text style={[styles.subtitle]}>Audience</Text>
              <Text
                style={{
                  color: "green",
                  fontSize: 15,
                  fontWeight: "500",
                  justifyContent: "flex-end",
                }}
              >
                Beginners
              </Text>
            </View>

            <View
              style={{
                marginBottom: 15,
                display: "flex",
                flexDirection: "row",
              }}
            >
              <Text style={[styles.subtitle, {}]}>Company Size</Text>
              <Text style={{ fontSize: 15, fontWeight: "500" }}>Big</Text>
            </View>
            <View
              style={{
                marginBottom: 15,
                display: "flex",
                flexDirection: "row",
              }}
            >
              <Text style={styles.subtitle}>Risk/Profit</Text>
              <Text
                style={{
                  fontSize: 17,
                  fontWeight: "500",
                }}
              >
                2 / 5
              </Text>
            </View>
          </View>
        </View>
        <View style={{ marginHorizontal: 10 }}>
          <Text
            style={{
              marginVertical: 5,
              marginBottom: 15,
              fontWeight: "600",
              fontSize: 18,
              // color: "#808080",
            }}
          >
            Summary
          </Text>
          <Text
            style={{
              fontFamily: "Arial",
              fontWeight: "400",
              fontSize: 15,
              marginBottom: 30,
              color: "#505050",
            }}
          >
            Since position trading is done for a long period of time, the market
            data above is a month long data. Based on the history of stock price
            before March 31 where the stock reached its peak, the current stock
            price could be considered low. Therefore, based on the trends, it
            can be assumed that the stock price will increase.
          </Text>
        </View>
      </View>
    </ScrollView>
  );
}

export function Week3({ navigation }) {
  return (
    <ScrollView>
      <View style={{ marginHorizontal: 0 }}>
        <Text style={styles.title}>Swing Trading</Text>

        <Text style={styles.summary}>
          Swing traders buy on lows and sell on highs, when there is high
          volatility. This strategy requires less time looking at the chart
          compared to other strategies, and has potentials for high profit.
          Unlike day trading, traders can trade even when the markets are
          closed.{" "}
        </Text>

        <Image
          style={styles.image}
          source={require("../../data/Weeks/week3.png")}
        ></Image>
        <View
          style={{
            // display: "flex",
            // flexDirection: "row",
            marginBottom: 10,
            justifyContent: "space-around",
          }}
        ></View>
        <View style={{ marginHorizontal: 10 }}>
          {/* <Text
            style={{
              marginVertical: 5,
              marginBottom: 15,
              fontWeight: "600",
              fontSize: 18,
              // color: "#808080",
            }}
          >
            Summary
          </Text> */}
          <View style={{ marginRight: 25, marginLeft: 10 }}>
            <View
              style={{
                marginBottom: 15,
                display: "flex",
                flexDirection: "row",
              }}
            >
              <Text style={[styles.subtitle]}>Audience</Text>
              <Text
                style={{
                  color: "#bf9c01",
                  fontSize: 15,
                  fontWeight: "600",
                  justifyContent: "flex-end",
                }}
              >
                Intermediate
              </Text>
            </View>

            <View
              style={{
                marginBottom: 15,
                display: "flex",
                flexDirection: "row",
              }}
            >
              <Text style={[styles.subtitle, {}]}>Company Size</Text>
              <Text style={{ fontSize: 15, fontWeight: "500" }}>
                Medium ~ Large
              </Text>
            </View>
            <View
              style={{
                marginBottom: 15,
                display: "flex",
                flexDirection: "row",
              }}
            >
              <Text style={styles.subtitle}>Risk/Profit</Text>
              <Text
                style={{
                  fontSize: 17,
                  fontWeight: "500",
                }}
              >
                3.5 / 5
              </Text>
            </View>
          </View>
          <Text
            style={{
              fontFamily: "Arial",
              fontWeight: "400",
              fontSize: 15,
              marginBottom: 30,
              color: "#505050",
            }}
          >
            Home Depot would be a good medium to large size company that has a
            low risk of going bankrupt but still exhibits some volatility as
            shown in the data. A swing trader would have purchased the stock on
            April 13th, assuming that it would be the low point. Then, the
            trader would have sold the stock recently.
          </Text>
        </View>
      </View>
    </ScrollView>
  );
}

export function Week4({ navigation }) {
  return (
    <ScrollView>
      <View style={{ marginHorizontal: 0 }}>
        <Text style={styles.title}>Scalping</Text>

        <Text style={styles.summary}>
          Scalping is one of the fastest methods of trading. Although scalping
          can be implemented in both volatile and less volatile markets, more
          volatile stocks are preferred for higher profit because scalpers
          profit off of price changes within a short period of time. However,
          because the changes are greatly unexpected, scalping inherently has a
          higher risk compared to other trading methods and requires more time
          commitment for the traders to constantly check the price. Although
          extensive knowledge is required, some experience is needed to identify
          entrance and exit points.{" "}
        </Text>
        <Image
          style={styles.image}
          source={require("../../data/Weeks/week4.png")}
        ></Image>
        <View
          style={{
            // display: "flex",
            // flexDirection: "row",
            marginBottom: 10,
            justifyContent: "space-around",
          }}
        >
          <View style={{ marginRight: 25, marginLeft: 10 }}>
            <View
              style={{
                marginBottom: 15,
                display: "flex",
                flexDirection: "row",
              }}
            >
              <Text style={[styles.subtitle]}>Audience</Text>
              <Text
                style={{
                  color: "green",
                  fontSize: 15,
                  fontWeight: "500",
                  justifyContent: "flex-end",
                }}
              >
                Beginners
              </Text>
            </View>

            <View
              style={{
                marginBottom: 15,
                display: "flex",
                flexDirection: "row",
              }}
            >
              <Text style={[styles.subtitle, {}]}>Company Size</Text>
              <Text style={{ fontSize: 15, fontWeight: "500" }}>
                Small ~ Medium
              </Text>
            </View>
            <View
              style={{
                marginBottom: 15,
                display: "flex",
                flexDirection: "row",
              }}
            >
              <Text style={styles.subtitle}>Risk/Profit</Text>
              <Text
                style={{
                  fontSize: 17,
                  fontWeight: "500",
                }}
              >
                4.5 / 5
              </Text>
            </View>
          </View>
        </View>
        <View style={{ marginHorizontal: 10 }}>
          <Text
            style={{
              marginVertical: 5,
              marginBottom: 15,
              fontWeight: "600",
              fontSize: 18,
              // color: "#808080",
            }}
          >
            Summary
          </Text>
          <Text
            style={{
              fontFamily: "Arial",
              fontWeight: "400",
              fontSize: 15,
              marginBottom: 30,
              color: "#505050",
            }}
          >
            The company shown called Skillz Inc is a small company that has a
            volatile stock as shown by the 5.50 percent increase in the stock
            price. A scalping trader would try to buy on low points and sell on
            high points throughout the graph.
          </Text>
        </View>
      </View>
    </ScrollView>
  );
}

export function Week5({ navigation }) {
  return (
    <ScrollView>
      <View style={{ marginHorizontal: 0 }}>
        <Text style={styles.title}>News Trading</Text>

        {/* <Image
          style={{ marginLeft: 10, width: 350, height: 250, marginBottom: 30 }}
          source={require("../../data/week2.png")}
        ></Image> */}
        <View
          style={{
            // display: "flex",
            // flexDirection: "row",
            marginBottom: 10,
            justifyContent: "space-around",
          }}
        >
          <View style={{ marginRight: 25, marginLeft: 10 }}>
            <View
              style={{
                marginBottom: 15,
                display: "flex",
                flexDirection: "row",
              }}
            >
              <Text style={[styles.subtitle]}>Audience</Text>
              <Text
                style={{
                  color: "green",
                  fontSize: 15,
                  fontWeight: "500",
                  justifyContent: "flex-end",
                }}
              >
                Beginner
              </Text>
              <Text> & </Text>
              <Text
                style={{
                  color: "#bf9c01",
                  fontSize: 15,
                  fontWeight: "600",
                  justifyContent: "flex-end",
                }}
              >
                Intermediate
              </Text>
            </View>

            <View
              style={{
                marginBottom: 15,
                display: "flex",
                flexDirection: "row",
              }}
            >
              <Text style={[styles.subtitle, {}]}>Company Size</Text>
              <Text style={{ fontSize: 15, fontWeight: "500" }}>All</Text>
            </View>
            <View
              style={{
                marginBottom: 15,
                display: "flex",
                flexDirection: "row",
              }}
            >
              <Text style={styles.subtitle}>Risk/Profit</Text>
              <Text
                style={{
                  fontSize: 17,
                  fontWeight: "500",
                }}
              >
                2 / 5
              </Text>
            </View>
          </View>
        </View>
        <View style={{ marginHorizontal: 10 }}>
          <Text
            style={{
              marginVertical: 5,
              marginBottom: 15,
              fontWeight: "600",
              fontSize: 18,
              // color: "#808080",
            }}
          >
            Summary
          </Text>
          <Text
            style={{
              fontFamily: "Arial",
              fontWeight: "400",
              fontSize: 15,
              marginBottom: 30,
              color: "#505050",
            }}
          >
            Following news releases, traders quickly anticipate the impact on
            stocks and act upon the expectations. There is a clearly defined
            entry and exit point, which is when the news is released which
            allows constant standards for traders. There are also many trading
            opportunities as there are various news on companies from diverse
            fields.
          </Text>
        </View>
      </View>
    </ScrollView>
  );
}

export function Week6({ navigation }) {
  return (
    <ScrollView>
      <View style={{ marginHorizontal: 0 }}>
        <Text style={styles.title}>End of day Trading</Text>
        <Text style={styles.summary}>
          Traders enter when the market is about to close, and trade based on
          previous day’s data. End of day trading requires less time commitment
          compared to other strategies. Traders have to be aware of how the end
          of day market operates, as they operate very differently from normal
          day trading. For example, transactions take place every 5 minutes
          only.{" "}
        </Text>
        <Image
          style={styles.image}
          source={require("../../data/Weeks/week6.png")}
        ></Image>
        <View
          style={{
            // display: "flex",
            // flexDirection: "row",
            marginBottom: 10,
            justifyContent: "space-around",
          }}
        >
          <View style={{ marginRight: 25, marginLeft: 10 }}>
            <View
              style={{
                marginBottom: 15,
                display: "flex",
                flexDirection: "row",
              }}
            >
              <Text style={[styles.subtitle]}>Audience</Text>
              <Text
                style={{
                  color: "#bf9c01",
                  fontSize: 15,
                  fontWeight: "500",
                  justifyContent: "flex-end",
                }}
              >
                Intermediate
              </Text>
              <Text> & </Text>
              <Text
                style={{
                  color: "red",
                  fontSize: 15,
                  fontWeight: "500",
                  justifyContent: "flex-end",
                }}
              >
                Advanced
              </Text>
            </View>

            <View
              style={{
                marginBottom: 15,
                display: "flex",
                flexDirection: "row",
              }}
            >
              <Text style={[styles.subtitle, {}]}>Company Size</Text>
              <Text style={{ fontSize: 15, fontWeight: "500" }}>Small</Text>
            </View>
            <View
              style={{
                marginBottom: 15,
                display: "flex",
                flexDirection: "row",
              }}
            >
              <Text style={styles.subtitle}>Risk/Profit</Text>
              <Text
                style={{
                  fontSize: 17,
                  fontWeight: "500",
                }}
              >
                3.5 / 5
              </Text>
            </View>
          </View>
        </View>
        <View style={{ marginHorizontal: 10 }}>
          {/* <Text
            style={{
              marginVertical: 5,
              marginBottom: 15,
              fontWeight: "600",
              fontSize: 18,
              // color: "#808080",
            }}
          >
            Summary
          </Text> */}
          <Text
            style={{
              fontFamily: "Arial",
              fontWeight: "400",
              fontSize: 15,
              marginBottom: 30,
              color: "#505050",
            }}
          >
            The stock enters an end of day market after 4 pm as shown with a
            gray line. As indicated in the graph, the stock behaves very
            differently in an end of day market, which is a reason why
            experience and understanding of the end of day market is required.
          </Text>
        </View>
      </View>
    </ScrollView>
  );
}

export function Week7({ navigation }) {
  return (
    <ScrollView>
      <View style={{ marginHorizontal: 0 }}>
        <Text style={styles.title}>Breakout Trading</Text>
        <Text style={styles.summary}>
          Breakout trading is a type of day trading, and focuses on where
          support happens. When the price falls below the (what people conceive
          as minimum price), traders enter, assuming that the stocks will
          increase due to support. Support occurs when the price of the stock
          has dropped too much, and traders come in to exploit the price
          differences, but end up supporting the price.
        </Text>
        <Image
          style={styles.image}
          source={require("../../data/Weeks/week7.png")}
        ></Image>
        <View
          style={{
            // display: "flex",
            // flexDirection: "row",
            marginBottom: 10,
            justifyContent: "space-around",
          }}
        >
          <View style={{ marginRight: 25, marginLeft: 10 }}>
            <View
              style={{
                marginBottom: 15,
                display: "flex",
                flexDirection: "row",
              }}
            >
              <Text style={[styles.subtitle]}>Audience</Text>
              <Text
                style={{
                  color: "#bf9c01",
                  fontSize: 15,
                  fontWeight: "500",
                  justifyContent: "flex-end",
                }}
              >
                Intermediate
              </Text>
              <Text> & </Text>
              <Text
                style={{
                  color: "red",
                  fontSize: 15,
                  fontWeight: "500",
                  justifyContent: "flex-end",
                }}
              >
                Advanced
              </Text>
            </View>

            <View
              style={{
                marginBottom: 15,
                display: "flex",
                flexDirection: "row",
              }}
            >
              <Text style={[styles.subtitle, {}]}>Company Size</Text>
              <Text style={{ fontSize: 15, fontWeight: "500" }}>Medium</Text>
            </View>
            <View
              style={{
                marginBottom: 15,
                display: "flex",
                flexDirection: "row",
              }}
            >
              <Text style={styles.subtitle}>Risk/Profit</Text>
              <Text
                style={{
                  fontSize: 17,
                  fontWeight: "500",
                }}
              >
                4 / 5
              </Text>
            </View>
          </View>
        </View>
        <View style={{ marginHorizontal: 10 }}>
          {/* <Text
            style={{
              marginVertical: 5,
              marginBottom: 15,
              fontWeight: "600",
              fontSize: 18,
              // color: "#808080",
            }}
          >
            Summary
          </Text> */}
          <Text
            style={{
              fontFamily: "Arial",
              fontWeight: "400",
              fontSize: 15,
              marginBottom: 30,
              color: "#505050",
            }}
          >
            3 pm would have been the ideal time of entrance because support
            occurs roughly at 3:00 pm. The price of the stock rose due to
            support after 3 pm when traders came in to exploit the price
            differences
          </Text>
        </View>
      </View>
    </ScrollView>
  );
}
export function Week8({ navigation }) {
  return (
    <ScrollView>
      <View style={{ marginHorizontal: 0 }}>
        <Text style={styles.title}>Pullback Trading</Text>
        <Text style={styles.summary}>
          Traders enter when they spot pullbacks, based on assumption that the
          stock will move to the opposite direction of the trend minorly. For
          example, the stock may experience minor/temporary upturn during a
          downward trend and vice versa. Pullback trading is different from
          breakout trading in that pullback trading relies on the past data of
          the stock to identify an entrance point where the stock decreases
          without a major reason.{" "}
        </Text>
        <Image
          style={styles.image}
          source={require("../../data/Weeks/week8.png")}
        ></Image>
        <View
          style={{
            // display: "flex",
            // flexDirection: "row",
            marginBottom: 10,
            justifyContent: "space-around",
          }}
        >
          <View style={{ marginRight: 25, marginLeft: 10 }}>
            <View
              style={{
                marginBottom: 15,
                display: "flex",
                flexDirection: "row",
              }}
            >
              <Text style={[styles.subtitle]}>Audience</Text>
              <Text
                style={{
                  color: "#bf9c01",
                  fontSize: 15,
                  fontWeight: "500",
                  justifyContent: "flex-end",
                }}
              >
                Intermediate
              </Text>
            </View>

            <View
              style={{
                marginBottom: 15,
                display: "flex",
                flexDirection: "row",
              }}
            >
              <Text style={[styles.subtitle, {}]}>Company Size</Text>
              <Text style={{ fontSize: 15, fontWeight: "500" }}>Medium</Text>
            </View>
            <View
              style={{
                marginBottom: 15,
                display: "flex",
                flexDirection: "row",
              }}
            >
              <Text style={styles.subtitle}>Risk/Profit</Text>
              <Text
                style={{
                  fontSize: 17,
                  fontWeight: "500",
                }}
              >
                4 / 5
              </Text>
            </View>
          </View>
        </View>
        <View style={{ marginHorizontal: 10 }}>
          {/* <Text
            style={{
              marginVertical: 5,
              marginBottom: 15,
              fontWeight: "600",
              fontSize: 18,
              // color: "#808080",
            }}
          >
            Summary
          </Text> */}
          <Text
            style={{
              fontFamily: "Arial",
              fontWeight: "400",
              fontSize: 15,
              marginBottom: 30,
              color: "#505050",
            }}
          >
            A pullback trader would purchase the stock around April 13th after
            the drop, assuming that the stock price will go back up.
          </Text>
        </View>
      </View>
    </ScrollView>
  );
}

export function Week9({ navigation }) {
  return (
    <ScrollView>
      <View style={{ marginHorizontal: 0 }}>
        <Text style={styles.title}>Moving average trading</Text>
        <Text style={styles.summary}>
          Moving average trading is another type of day trading. Under the
          assumption that smaller moving averages follow price faster than
          larger moving averages, traders enter when a crossover occurs.
          Although these moving averages will not accurately depict the highs
          and lows, it is a good indicator of highs and lows of the stock
          prices. Therefore, traders will purchase when the price is below the
          average assuming that it will go back up because average value does
          not change drastically.
        </Text>
        <Image
          style={styles.image}
          source={require("../../data/Weeks/week9.jpg")}
        ></Image>
        <View
          style={{
            // display: "flex",
            // flexDirection: "row",
            marginBottom: 10,
            justifyContent: "space-around",
          }}
        >
          <View style={{ marginRight: 25, marginLeft: 10 }}>
            <View
              style={{
                marginBottom: 15,
                display: "flex",
                flexDirection: "row",
              }}
            >
              <Text style={[styles.subtitle]}>Audience</Text>
              <Text
                style={{
                  color: "green",
                  fontSize: 15,
                  fontWeight: "500",
                  justifyContent: "flex-end",
                }}
              >
                Beginners
              </Text>
            </View>

            <View
              style={{
                marginBottom: 15,
                display: "flex",
                flexDirection: "row",
              }}
            >
              <Text style={[styles.subtitle, {}]}>Company Size</Text>
              <Text style={{ fontSize: 15, fontWeight: "500" }}>Medium</Text>
            </View>
            <View
              style={{
                marginBottom: 15,
                display: "flex",
                flexDirection: "row",
              }}
            >
              <Text style={styles.subtitle}>Risk/Profit</Text>
              <Text
                style={{
                  fontSize: 17,
                  fontWeight: "500",
                }}
              >
                3 / 5
              </Text>
            </View>
          </View>
        </View>
        <View style={{ marginHorizontal: 10 }}>
          {/* <Text
            style={{
              marginVertical: 5,
              marginBottom: 15,
              fontWeight: "600",
              fontSize: 18,
              // color: "#808080",
            }}
          >
            Summary
          </Text> */}
          <Text
            style={{
              fontFamily: "Arial",
              fontWeight: "400",
              fontSize: 15,
              marginBottom: 30,
              color: "#505050",
            }}
          >
            The blue line represents the moving average value of the stock.
            Reading the average value, a trader would enter around 12:00,
            observing that the price started to fall below the average value.
            Then, the trader would sell the stock around 6:00 when a crossover
            occurs and the stock price exceeds that of the average.
          </Text>
        </View>
      </View>
    </ScrollView>
  );
}

export function Week10({ navigation }) {
  return (
    <ScrollView>
      <View style={{ marginHorizontal: 0 }}>
        <Text style={styles.title}>Momentum Trading</Text>
        <Text style={styles.summary}>
          Buying a stock and holding it until there is a reverse sign of a stock
          price direction, because stocks tend to continue their movement in
          price direction when all the conditions are constant.{" "}
        </Text>
        <Image
          style={styles.image}
          source={require("../../data/Weeks/week10.png")}
        ></Image>
        <View
          style={{
            // display: "flex",
            // flexDirection: "row",
            marginBottom: 10,
            justifyContent: "space-around",
          }}
        >
          <View style={{ marginRight: 25, marginLeft: 10 }}>
            <View
              style={{
                marginBottom: 15,
                display: "flex",
                flexDirection: "row",
              }}
            >
              <Text style={[styles.subtitle]}>Audience</Text>
              <Text
                style={{
                  color: "#bf9c01",
                  fontSize: 15,
                  fontWeight: "600",
                  justifyContent: "flex-end",
                }}
              >
                Intermediate
              </Text>
            </View>

            <View
              style={{
                marginBottom: 15,
                display: "flex",
                flexDirection: "row",
              }}
            >
              <Text style={[styles.subtitle, {}]}>Company Size</Text>
              <Text style={{ fontSize: 15, fontWeight: "500" }}>Medium</Text>
            </View>
            <View
              style={{
                marginBottom: 15,
                display: "flex",
                flexDirection: "row",
              }}
            >
              <Text style={styles.subtitle}>Risk/Profit</Text>
              <Text
                style={{
                  fontSize: 17,
                  fontWeight: "500",
                }}
              >
                4
              </Text>
            </View>
          </View>
        </View>
        <View style={{ marginHorizontal: 10 }}>
          {/* <Text
            style={{
              marginVertical: 5,
              marginBottom: 15,
              fontWeight: "600",
              fontSize: 18,
              // color: "#808080",
            }}
          >
            Summary
          </Text> */}
          <Text
            style={{
              fontFamily: "Arial",
              fontWeight: "400",
              fontSize: 15,
              marginBottom: 30,
              color: "#505050",
            }}
          >
            A sudden increase on March 28th is noted. A momentum trader will
            enter on March 29th, assuming that the upward trajectory would
            continue.
          </Text>
        </View>
      </View>
    </ScrollView>
  );
}
export function Week11({ navigation }) {
  return (
    <ScrollView>
      <View style={{ marginHorizontal: 0 }}>
        <Text style={styles.title}>IPOs (Initial Public Offering)</Text>
        <Text style={styles.summary}>
          When the stock first enters the market, traders exploit the largely
          fluctuating price that occurs because of a sudden inflow of capital to
          the stock. There are two ways that the traders can exploit this
          fluctuation. Firstly, the traders can purchase the IPO assuming that
          the price will increase. Secondly, traders can wait for the
          fluctuation to decrease and purchase when the price becomes fairly
          low.{" "}
        </Text>
        <Image
          style={styles.image}
          source={require("../../data/Weeks/week11.png")}
        ></Image>
        <View
          style={{
            // display: "flex",
            // flexDirection: "row",
            marginBottom: 10,
            justifyContent: "space-around",
          }}
        >
          <View style={{ marginRight: 25, marginLeft: 10 }}>
            <View
              style={{
                marginBottom: 15,
                display: "flex",
                flexDirection: "row",
              }}
            >
              <Text style={[styles.subtitle]}>Audience</Text>
              <Text
                style={{
                  color: "green",
                  fontSize: 15,
                  fontWeight: "500",
                  justifyContent: "flex-end",
                }}
              >
                Beginners
              </Text>
            </View>

            <View
              style={{
                marginBottom: 15,
                display: "flex",
                flexDirection: "row",
              }}
            >
              <Text style={[styles.subtitle, {}]}>Company Size</Text>
              <Text style={{ fontSize: 15, fontWeight: "500" }}>All</Text>
            </View>
            <View
              style={{
                marginBottom: 15,
                display: "flex",
                flexDirection: "row",
              }}
            >
              <Text style={styles.subtitle}>Risk/Profit</Text>
              <Text
                style={{
                  fontSize: 17,
                  fontWeight: "500",
                }}
              >
                2 / 5
              </Text>
            </View>
          </View>
        </View>
        <View style={{ marginHorizontal: 10 }}>
          {/* <Text
            style={{
              marginVertical: 5,
              marginBottom: 15,
              fontWeight: "600",
              fontSize: 18,
              // color: "#808080",
            }}
          >
            Summary
          </Text> */}
          <Text
            style={{
              fontFamily: "Arial",
              fontWeight: "400",
              fontSize: 15,
              marginBottom: 30,
              color: "#505050",
            }}
          >
            The graph shows the recently IPOed stock. It is shown that it starts
            at a price of 8, but increases drastically after it is released to
            the public. A trader who wishes to exploit these differences would
            have purchased the stock as soon as it was released to the market
            and sold it once it reached the peak.
          </Text>
        </View>
      </View>
    </ScrollView>
  );
}

export function Week12({ navigation }) {
  return (
    <ScrollView>
      <View style={{ marginHorizontal: 0 }}>
        <Text style={styles.title}>Short Selling</Text>
        <Text style={styles.summary}>
          Traders borrow a stock and sell the stock at a high point. Later, the
          trader purchases the stock at a lower price and pays back.{" "}
        </Text>
        <Image
          style={styles.image}
          source={require("../../data/Weeks/week12.png")}
        ></Image>
        <View
          style={{
            // display: "flex",
            // flexDirection: "row",
            marginBottom: 10,
            justifyContent: "space-around",
          }}
        >
          <View style={{ marginRight: 25, marginLeft: 10 }}>
            <View
              style={{
                marginBottom: 15,
                display: "flex",
                flexDirection: "row",
              }}
            >
              <Text style={[styles.subtitle]}>Audience</Text>
              <Text
                style={{
                  color: "red",
                  fontSize: 15,
                  fontWeight: "500",
                  justifyContent: "flex-end",
                }}
              >
                Advanced
              </Text>
            </View>

            <View
              style={{
                marginBottom: 15,
                display: "flex",
                flexDirection: "row",
              }}
            >
              <Text style={[styles.subtitle, {}]}>Company Size</Text>
              <Text style={{ fontSize: 15, fontWeight: "500" }}>All</Text>
            </View>
            <View
              style={{
                marginBottom: 15,
                display: "flex",
                flexDirection: "row",
              }}
            >
              <Text style={styles.subtitle}>Risk/Profit</Text>
              <Text
                style={{
                  fontSize: 17,
                  fontWeight: "500",
                }}
              >
                4.5 / 5
              </Text>
            </View>
          </View>
        </View>
        <View style={{ marginHorizontal: 10 }}>
          {/* <Text
            style={{
              marginVertical: 5,
              marginBottom: 15,
              fontWeight: "600",
              fontSize: 18,
              // color: "#808080",
            }}
          >
            Summary
          </Text> */}
          <Text
            style={{
              fontFamily: "Arial",
              fontWeight: "400",
              fontSize: 15,
              marginBottom: 30,
              color: "#505050",
            }}
          >
            If a trader were to use the short selling method, the trader would
            borrow and sell the stock in December 2022 where the stock price is
            at a high and would later purchase the stock in January 2023 where
            the stock price is lower.
          </Text>
        </View>
      </View>
    </ScrollView>
  );
}

export function Week13({ navigation }) {
  return (
    <ScrollView>
      <View style={{ marginHorizontal: 0 }}>
        <Text
          style={{
            fontSize: 22,
            textAlign: "center",
            fontWeight: "600",
            marginTop: 20,
            marginBottom: 40,
          }}
        >
          Margin Trading
        </Text>
        {/* <Image
          style={{ marginLeft: 10, width: 350, height: 250, marginBottom: 30 }}
          source={require("../../data/Weeks/week2.png")}
        ></Image> */}
        <View
          style={{
            // display: "flex",
            // flexDirection: "row",
            marginBottom: 10,
            justifyContent: "space-around",
          }}
        >
          <View style={{ marginRight: 25, marginLeft: 10 }}>
            <View
              style={{
                marginBottom: 15,
                display: "flex",
                flexDirection: "row",
              }}
            >
              <Text style={[styles.subtitle]}>Audience</Text>
              <Text
                style={{
                  color: "#bf9c01",
                  fontSize: 15,
                  fontWeight: "600",
                  justifyContent: "flex-end",
                }}
              >
                Intermediate
              </Text>
              <Text> & </Text>
              <Text
                style={{
                  color: "red",
                  fontSize: 15,
                  fontWeight: "500",
                  justifyContent: "flex-end",
                }}
              >
                Advanced
              </Text>
            </View>

            <View
              style={{
                marginBottom: 15,
                display: "flex",
                flexDirection: "row",
              }}
            >
              <Text style={[styles.subtitle, {}]}>Company Size</Text>
              <Text style={{ fontSize: 15, fontWeight: "500" }}>All</Text>
            </View>
            <View
              style={{
                marginBottom: 15,
                display: "flex",
                flexDirection: "row",
              }}
            >
              <Text style={styles.subtitle}>Risk/Profit</Text>
              <Text
                style={{
                  fontSize: 17,
                  fontWeight: "500",
                }}
              >
                4.5 / 5
              </Text>
            </View>
          </View>
        </View>
        <View style={{ marginHorizontal: 10 }}>
          <Text
            style={{
              marginVertical: 5,
              marginBottom: 15,
              fontWeight: "600",
              fontSize: 18,
              // color: "#808080",
            }}
          >
            Summary
          </Text>
          <Text
            style={{
              fontFamily: "Arial",
              fontWeight: "400",
              fontSize: 15,
              marginBottom: 30,
              color: "#505050",
            }}
          >
            There is a separate account for margin trading. Traders increase
            their capital by borrowing. Although the increased amount of capital
            generates greater profit, it also provides greater chances of loss
            when the stock price declines. Margin trading is different from
            short selling in that short sellers borrow stocks whereas margin
            traders borrow funds.
          </Text>
        </View>
      </View>
    </ScrollView>
  );
}

export function Week14({ navigation }) {
  return (
    <ScrollView>
      <View style={{ marginHorizontal: 0 }}>
        <Text style={styles.title}>Funds Trading</Text>
        <Text style={styles.summary}>
          Funds Trading is unique in that the traders do not analyze anything,
          but purchase funds that are simply available in the market. There are
          various funds such as ETFs and index funds. Funds are invested in
          multiple stocks and therefore have less risks as the capital is
          automatically diversified.{" "}
        </Text>
        <Image
          // style={styles.image}
          style={{
            marginLeft: "2.25%",
            width: screenWidth * 0.95,
            height: screenHeigth * 0.2,
            resizeMode: "contain",
          }}
          source={require("../../data/Weeks/week14.png")}
        ></Image>
        <View
          style={{
            // display: "flex",
            // flexDirection: "row",
            marginBottom: 10,
            justifyContent: "space-around",
          }}
        >
          <View style={{ marginRight: 25, marginLeft: 10 }}>
            <View
              style={{
                marginBottom: 15,
                display: "flex",
                flexDirection: "row",
              }}
            >
              <Text style={[styles.subtitle]}>Audience</Text>
              <Text
                style={{
                  color: "green",
                  fontSize: 15,
                  fontWeight: "500",
                  justifyContent: "flex-end",
                }}
              >
                Beginners
              </Text>
            </View>

            <View
              style={{
                marginBottom: 15,
                display: "flex",
                flexDirection: "row",
              }}
            >
              <Text style={[styles.subtitle, {}]}>Company Size</Text>
              <Text style={{ fontSize: 15, fontWeight: "500" }}>N/A</Text>
            </View>
            <View
              style={{
                marginBottom: 15,
                display: "flex",
                flexDirection: "row",
              }}
            >
              <Text style={styles.subtitle}>Risk/Profit</Text>
              <Text
                style={{
                  fontSize: 17,
                  fontWeight: "500",
                }}
              >
                1 / 5
              </Text>
            </View>
          </View>
        </View>
        <View style={{ marginHorizontal: 10 }}>
          {/* <Text
            style={{
              marginVertical: 5,
              marginBottom: 15,
              fontWeight: "600",
              fontSize: 18,
              // color: "#808080",
            }}
          >
            Summary
          </Text> */}
          <Text
            style={{
              fontFamily: "Arial",
              fontWeight: "400",
              fontSize: 15,
              marginBottom: 30,
              color: "#505050",
            }}
          >
            This chart illustrates the graph of a fund. Same idea of buy low and
            sell high is applied to fund trading.
          </Text>
        </View>
      </View>
    </ScrollView>
  );
}
export function Week15({ navigation }) {
  return (
    <ScrollView>
      <View style={{ marginHorizontal: 0 }}>
        <Text style={styles.title}>Seasonal Trading</Text>
        <Text style={styles.summary}>
          There are companies that perform better during a specific season such
          as ski companies. Seasonal traders invest in these companies. They
          purchase stocks of these companies during off season when the stock
          price is relatively low and sell on season when the price is
          relatively higher.{" "}
        </Text>
        <Image
          style={styles.image}
          source={require("../../data/Weeks/week15.png")}
        ></Image>
        <View
          style={{
            // display: "flex",
            // flexDirection: "row",
            marginBottom: 10,
            justifyContent: "space-around",
          }}
        >
          <View style={{ marginRight: 25, marginLeft: 10 }}>
            <View
              style={{
                marginBottom: 15,
                display: "flex",
                flexDirection: "row",
              }}
            >
              <Text style={[styles.subtitle]}>Audience</Text>
              <Text
                style={{
                  color: "green",
                  fontSize: 15,
                  fontWeight: "500",
                  justifyContent: "flex-end",
                }}
              >
                Beginners
              </Text>
            </View>

            <View
              style={{
                marginBottom: 15,
                display: "flex",
                flexDirection: "row",
              }}
            >
              <Text style={[styles.subtitle, {}]}>Company Size</Text>
              <Text style={{ fontSize: 15, fontWeight: "500" }}>Medium</Text>
            </View>
            <View
              style={{
                marginBottom: 15,
                display: "flex",
                flexDirection: "row",
              }}
            >
              <Text style={styles.subtitle}>Risk/Profit</Text>
              <Text
                style={{
                  fontSize: 17,
                  fontWeight: "500",
                }}
              >
                2.5 / 5
              </Text>
            </View>
          </View>
        </View>
        <View style={{ marginHorizontal: 10 }}>
          {/* <Text
            style={{
              marginVertical: 5,
              marginBottom: 15,
              fontWeight: "600",
              fontSize: 18,
              // color: "#808080",
            }}
          >
            Summary
          </Text> */}
          <Text
            style={{
              fontFamily: "Arial",
              fontWeight: "400",
              fontSize: 15,
              marginBottom: 30,
              color: "#505050",
            }}
          >
            Watsco is an air conditioning company, and therefore is a summer
            business. Based upon this knowledge, a seasonal trader would expect
            watsco’s stock price to increase during summer. Therefore, the
            trader would purchase the stock during winter and sell during the
            summer.
          </Text>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  subtitle: {
    fontSize: 16,
    fontWeight: "600",
    flexGrow: 1,
    color: "#303030",
  },
  image: {
    marginLeft: "2.25%",
    width: screenWidth * 0.95,
    height: screenHeigth * 0.35,
    resizeMode: "contain",
  },
  summary: {
    fontFamily: "Arial",
    fontWeight: "400",
    fontSize: 15,
    color: "#505050",
    marginHorizontal: 10,
    marginBottom: "7%",
  },
  title: {
    fontSize: 22,
    textAlign: "center",
    fontWeight: "600",
    marginTop: 20,
    marginBottom: "5%",
  },
});
