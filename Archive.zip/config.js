export default options = {
  method: "GET",
  headers: {
    // "X-RapidAPI-Key": "3237c553e5mshde123631b52135cp166f44jsn5c0fc8607fce",
    // 지유's API Key
    "X-RapidAPI-Key": "d68d5c4dfbmshde48364f2cec6d7p132df0jsn03e3427dc4f6",
    "X-RapidAPI-Host": "yh-finance.p.rapidapi.com",
  },
};
