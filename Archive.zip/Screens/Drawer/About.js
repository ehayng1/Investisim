import {
  ScrollView,
  StyleSheet,
  Text,
  View,
  Image,
  Pressable,
} from "react-native";

export default function About() {
  return <Text>About Us</Text>;
}
